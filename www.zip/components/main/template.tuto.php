<?php
  $template = "<h1>Lorem Ipsum</h1>"
?>
