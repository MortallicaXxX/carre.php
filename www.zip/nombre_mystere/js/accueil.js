console.log("Le code de accueil.js a d�marr�");
